import { useMemo } from "react";
import { useSearchParams } from "react-router-dom";
import { getAllProducts } from "../api/client.js";
import { useAsync } from "../hooks/useAsync.js";
import ProductCard, { formatCategory } from "../components/ProductCard.jsx";
import { ProductGridSkeleton } from "../components/Skeletons.jsx";
import { ErrorState, EmptyState } from "../components/States.jsx";

const SORTS = {
  default: "Standart",
  "price-asc": "Narx: arzondan qimmatga",
  "price-desc": "Narx: qimmatdan arzonga",
};

export default function HomePage() {
  const [params, setParams] = useSearchParams();
  const q = params.get("q") ?? "";
  const category = params.get("category") ?? "all";
  const sort = params.get("sort") ?? "default";

  const { status, data, error, retry } = useAsync(
    (opts) => getAllProducts(opts),
    []
  );

  const update = (key, value, defaultValue) => {
    setParams(
      (prev) => {
        const next = new URLSearchParams(prev);
        if (!value || value === defaultValue) next.delete(key);
        else next.set(key, value);
        return next;
      },
      { replace: true }
    );
  };

  const products = data?.products ?? [];

  const categories = useMemo(
    () => [...new Set(products.map((p) => p.category))].sort(),
    [products]
  );

  const visible = useMemo(() => {
    const term = q.trim().toLowerCase();
    let list = products.filter(
      (p) =>
        (category === "all" || p.category === category) &&
        (!term || p.title.toLowerCase().includes(term))
    );
    if (sort === "price-asc") list = [...list].sort((a, b) => a.price - b.price);
    if (sort === "price-desc") list = [...list].sort((a, b) => b.price - a.price);
    return list;
  }, [products, q, category, sort]);

  const reset = () => setParams({}, { replace: true });

  return (
    <div className="space-y-6">
      <div className="grid gap-3 sm:grid-cols-[1fr_auto_auto]">
        <input
          type="search"
          value={q}
          onChange={(e) => update("q", e.target.value, "")}
          placeholder="Mahsulot nomi bo'yicha qidirish..."
          className="rounded-lg border bg-white px-4 py-2 outline-none focus:ring-2 focus:ring-indigo-500"
        />
        <select
          value={category}
          onChange={(e) => update("category", e.target.value, "all")}
          disabled={status !== "success"}
          className="rounded-lg border bg-white px-3 py-2 disabled:opacity-60"
        >
          <option value="all">Barcha kategoriyalar</option>
          {categories.map((c) => (
            <option key={c} value={c}>
              {formatCategory(c)}
            </option>
          ))}
        </select>
        <select
          value={sort}
          onChange={(e) => update("sort", e.target.value, "default")}
          className="rounded-lg border bg-white px-3 py-2"
        >
          {Object.entries(SORTS).map(([value, label]) => (
            <option key={value} value={value}>
              {label}
            </option>
          ))}
        </select>
      </div>

      {status === "loading" && <ProductGridSkeleton />}

      {status === "error" && <ErrorState message={error} onRetry={retry} />}

      {status === "success" && visible.length === 0 && (
        <EmptyState
          hint="Qidiruv yoki filtrni o'zgartirib ko'ring."
          action={
            <button
              type="button"
              onClick={reset}
              className="mt-4 rounded-lg bg-indigo-600 px-4 py-2 text-sm text-white hover:bg-indigo-700"
            >
              Filtrlarni tozalash
            </button>
          }
        />
      )}

      {status === "success" && visible.length > 0 && (
        <>
          <p className="text-sm text-gray-500">{visible.length} ta mahsulot</p>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
            {visible.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </>
      )}
    </div>
  );
}
