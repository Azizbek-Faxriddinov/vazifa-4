import { useState } from "react";
import { Link, useParams } from "react-router-dom";
import { getProduct } from "../api/client.js";
import { useAsync } from "../hooks/useAsync.js";
import FavoriteButton from "../components/FavoriteButton.jsx";
import { formatCategory } from "../components/ProductCard.jsx";
import { ProductDetailSkeleton } from "../components/Skeletons.jsx";
import { ErrorState } from "../components/States.jsx";

function Gallery({ product }) {
  const images = product.images?.length ? product.images : [product.thumbnail];
  const [active, setActive] = useState(0);

  return (
    <div className="space-y-3">
      <div className="aspect-square overflow-hidden rounded-xl border bg-gray-100">
        <img
          src={images[active]}
          alt={product.title}
          className="h-full w-full object-cover"
        />
      </div>
      {images.length > 1 && (
        <div className="flex flex-wrap gap-2">
          {images.map((src, i) => (
            <button
              key={src}
              type="button"
              onClick={() => setActive(i)}
              aria-label={`Rasm ${i + 1}`}
              className={`h-16 w-16 overflow-hidden rounded-lg border-2 bg-gray-100 ${
                i === active ? "border-indigo-600" : "border-transparent"
              }`}
            >
              <img src={src} alt="" loading="lazy" className="h-full w-full object-cover" />
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function Spec({ label, value }) {
  if (value === undefined || value === null || value === "") return null;
  return (
    <div className="flex justify-between gap-4 border-b py-2 text-sm">
      <dt className="text-gray-500">{label}</dt>
      <dd className="text-right font-medium">{value}</dd>
    </div>
  );
}

export default function ProductPage() {
  const { id } = useParams();
  const { status, data: product, error, retry } = useAsync(
    (opts) => getProduct(id, opts),
    [id]
  );

  return (
    <div className="space-y-6">
      <Link to="/" className="text-sm text-indigo-600 hover:underline">
        ← Katalogga qaytish
      </Link>

      {status === "loading" && <ProductDetailSkeleton />}
      {status === "error" && <ErrorState message={error} onRetry={retry} />}

      {status === "success" && (
        <div className="grid gap-8 md:grid-cols-2">
          <Gallery product={product} key={product.id} />

          <div className="space-y-5">
            <div>
              <p className="text-xs uppercase tracking-wide text-gray-500">
                {formatCategory(product.category)}
                {product.brand ? ` · ${product.brand}` : ""}
              </p>
              <div className="mt-1 flex items-start justify-between gap-4">
                <h1 className="text-2xl font-bold">{product.title}</h1>
                <FavoriteButton product={product} className="shrink-0 border" />
              </div>
              <p className="mt-2 text-sm text-amber-500">
                ★ {product.rating}{" "}
                <span className="text-gray-500">
                  ({product.reviews?.length ?? 0} sharh)
                </span>
              </p>
            </div>

            <div className="flex items-baseline gap-3">
              <span className="text-3xl font-bold text-indigo-600">${product.price}</span>
              {product.discountPercentage > 0 && (
                <span className="rounded bg-red-100 px-2 py-0.5 text-sm text-red-600">
                  -{Math.round(product.discountPercentage)}%
                </span>
              )}
            </div>

            <p className="leading-relaxed text-gray-700">{product.description}</p>

            <dl>
              <Spec label="Mavjudligi" value={product.availabilityStatus} />
              <Spec label="Omborda" value={product.stock && `${product.stock} dona`} />
              <Spec label="SKU" value={product.sku} />
              <Spec label="Og'irligi" value={product.weight && `${product.weight} g`} />
              <Spec
                label="O'lchamlari"
                value={
                  product.dimensions &&
                  `${product.dimensions.width} × ${product.dimensions.height} × ${product.dimensions.depth}`
                }
              />
              <Spec label="Kafolat" value={product.warrantyInformation} />
              <Spec label="Yetkazib berish" value={product.shippingInformation} />
              <Spec label="Qaytarish" value={product.returnPolicy} />
            </dl>

            {product.tags?.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {product.tags.map((t) => (
                  <span key={t} className="rounded-full bg-gray-100 px-3 py-1 text-xs">
                    #{t}
                  </span>
                ))}
              </div>
            )}
          </div>

          {product.reviews?.length > 0 && (
            <section className="space-y-3 md:col-span-2">
              <h2 className="text-lg font-semibold">Sharhlar</h2>
              <ul className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                {product.reviews.map((r, i) => (
                  <li key={i} className="rounded-lg border bg-white p-4 text-sm">
                    <p className="text-amber-500">{"★".repeat(r.rating)}</p>
                    <p className="mt-1">{r.comment}</p>
                    <p className="mt-2 text-xs text-gray-500">{r.reviewerName}</p>
                  </li>
                ))}
              </ul>
            </section>
          )}
        </div>
      )}
    </div>
  );
}
