import { Link } from "react-router-dom";
import { useFavorites } from "../context/FavoritesContext.jsx";
import ProductCard from "../components/ProductCard.jsx";
import { EmptyState } from "../components/States.jsx";

export default function FavoritesPage() {
  const { favorites } = useFavorites();

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Sevimlilar</h1>
      {favorites.length === 0 ? (
        <EmptyState
          title="Sevimlilar ro'yxati bo'sh"
          hint="Mahsulot kartasidagi ♡ tugmasini bosing."
          action={
            <Link
              to="/"
              className="mt-4 inline-block rounded-lg bg-indigo-600 px-4 py-2 text-sm text-white hover:bg-indigo-700"
            >
              Katalogga o'tish
            </Link>
          }
        />
      ) : (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {favorites.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      )}
    </div>
  );
}
