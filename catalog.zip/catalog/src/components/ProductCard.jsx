import { Link } from "react-router-dom";
import FavoriteButton from "./FavoriteButton.jsx";

export function formatCategory(slug = "") {
  return slug.replace(/-/g, " ").replace(/^\w/, (c) => c.toUpperCase());
}

export default function ProductCard({ product }) {
  return (
    <Link
      to={`/product/${product.id}`}
      className="group block overflow-hidden rounded-xl border bg-white shadow-sm transition hover:shadow-md"
    >
      <div className="relative aspect-square bg-gray-100">
        <img
          src={product.thumbnail}
          alt={product.title}
          loading="lazy"
          className="h-full w-full object-cover transition group-hover:scale-105"
        />
        <FavoriteButton product={product} className="absolute right-2 top-2" />
      </div>
      <div className="space-y-1 p-3">
        <p className="text-xs uppercase tracking-wide text-gray-500">
          {formatCategory(product.category)}
        </p>
        <h3 className="line-clamp-1 font-medium">{product.title}</h3>
        <div className="flex items-center justify-between">
          <span className="font-semibold text-indigo-600">${product.price}</span>
          <span className="text-sm text-amber-500">★ {product.rating}</span>
        </div>
      </div>
    </Link>
  );
}
