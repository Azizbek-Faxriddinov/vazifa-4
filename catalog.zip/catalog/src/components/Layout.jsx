import { Link, NavLink, Outlet } from "react-router-dom";
import { useFavorites } from "../context/FavoritesContext.jsx";

export default function Layout() {
  const { favorites } = useFavorites();
  const linkClass = ({ isActive }) =>
    `rounded-md px-3 py-1.5 text-sm font-medium ${
      isActive ? "bg-indigo-600 text-white" : "text-gray-700 hover:bg-gray-100"
    }`;

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-10 border-b bg-white/90 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
          <Link to="/" className="text-lg font-bold text-indigo-600">
            🛍️ Katalog
          </Link>
          <nav className="flex gap-2">
            <NavLink to="/" end className={linkClass}>
              Mahsulotlar
            </NavLink>
            <NavLink to="/favorites" className={linkClass}>
              Sevimlilar ({favorites.length})
            </NavLink>
          </nav>
        </div>
      </header>
      <main className="mx-auto max-w-6xl px-4 py-6">
        <Outlet />
      </main>
    </div>
  );
}
