import { useFavorites } from "../context/FavoritesContext.jsx";

export default function FavoriteButton({ product, className = "" }) {
  const { isFavorite, toggleFavorite } = useFavorites();
  const active = isFavorite(product.id);

  return (
    <button
      type="button"
      aria-pressed={active}
      aria-label={active ? "Sevimlilardan olib tashlash" : "Sevimlilarga qo'shish"}
      onClick={(e) => {
        e.preventDefault();
        e.stopPropagation();
        toggleFavorite(product);
      }}
      className={`flex h-9 w-9 items-center justify-center rounded-full bg-white/90 text-xl shadow transition hover:scale-110 ${
        active ? "text-red-500" : "text-gray-400"
      } ${className}`}
    >
      {active ? "♥" : "♡"}
    </button>
  );
}
