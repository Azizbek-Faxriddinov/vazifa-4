export function ErrorState({ message, onRetry }) {
  return (
    <div role="alert" className="rounded-xl border border-red-200 bg-red-50 p-8 text-center">
      <p className="text-4xl">⚠️</p>
      <h2 className="mt-2 text-lg font-semibold text-red-700">Xatolik yuz berdi</h2>
      <p className="mt-1 text-sm text-red-600">{message}</p>
      <button
        type="button"
        onClick={onRetry}
        className="mt-4 rounded-lg bg-red-600 px-5 py-2 text-sm font-medium text-white hover:bg-red-700"
      >
        Qayta urinish
      </button>
    </div>
  );
}

export function EmptyState({ title = "Hech narsa topilmadi", hint, action }) {
  return (
    <div className="rounded-xl border border-dashed bg-white p-10 text-center">
      <p className="text-4xl">🔍</p>
      <h2 className="mt-2 text-lg font-semibold">{title}</h2>
      {hint && <p className="mt-1 text-sm text-gray-500">{hint}</p>}
      {action}
    </div>
  );
}
