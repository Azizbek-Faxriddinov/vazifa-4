import { useEffect, useState, useCallback } from "react";

// status: "loading" | "error" | "success"
export function useAsync(fetcher, deps) {
  const [state, setState] = useState({ status: "loading", data: null, error: null });
  const [attempt, setAttempt] = useState(0);

  useEffect(() => {
    const controller = new AbortController();
    setState({ status: "loading", data: null, error: null });
    fetcher({ signal: controller.signal })
      .then((data) => setState({ status: "success", data, error: null }))
      .catch((error) => {
        if (error.name === "AbortError") return;
        setState({
          status: "error",
          data: null,
          error:
            error instanceof TypeError
              ? "Tarmoq xatosi. Internet aloqasini tekshiring."
              : error.message,
        });
      });
    return () => controller.abort();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [...deps, attempt]);

  const retry = useCallback(() => setAttempt((a) => a + 1), []);
  return { ...state, retry };
}
