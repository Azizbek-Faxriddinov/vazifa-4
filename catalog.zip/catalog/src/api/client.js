const BASE_URL = import.meta.env.VITE_API_BASE_URL;

export async function fetchJson(path, { signal } = {}) {
  const res = await fetch(`${BASE_URL}${path}`, { signal });
  if (!res.ok) {
    const err = new Error(
      res.status === 404
        ? "Ma'lumot topilmadi (404)"
        : `Server xatosi: ${res.status}`
    );
    err.status = res.status;
    throw err;
  }
  return res.json();
}

export const getAllProducts = (opts) => fetchJson("/products?limit=0", opts);
export const getProduct = (id, opts) => fetchJson(`/products/${id}`, opts);
